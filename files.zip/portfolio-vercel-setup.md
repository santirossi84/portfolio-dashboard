# Setup en Vercel — Portfolio Dashboard

## Paso 1: Crear cuenta en Vercel (2 minutos)

1. Andá a https://vercel.com/signup
2. Tocá "Continue with GitHub" (o usa email si preferís)
3. Si no tenés GitHub, create una cuenta rápido en https://github.com/signup
4. Vercel te va a pedir acceso a tus repos — autorizá
5. Listo, estás dentro

## Paso 2: Crear el repositorio (1 minuto)

1. Andá a https://github.com/new
2. Nombre del repo: `portfolio-dashboard`
3. Hacé público (Public)
4. Tocá "Create repository"
5. **COPIAR** la URL que te da (algo como `https://github.com/tuusuario/portfolio-dashboard.git`)

## Paso 3: Subir el código (5 minutos — si usás Git por primera vez, 10)

### Opción A: Si ya usás Git / GitHub Desktop

```bash
git clone https://github.com/tuusuario/portfolio-dashboard.git
cd portfolio-dashboard
```

Descargá este archivo: `portfolio_dashboard.jsx` (que ya está en outputs)

Poné el archivo en la carpeta que creaste.

Luego:
```bash
git add .
git commit -m "Initial portfolio dashboard"
git push origin main
```

### Opción B: Si no querés tocar terminal (lo más fácil)

1. Andá a tu repo en GitHub (la URL que copiaste en Paso 2)
2. Tocá el botón **"Add file"** → **"Upload files"**
3. Arrastá estos archivos:
   - `portfolio_dashboard.jsx`
   - `next.config.js` (lo armo abajo)
   - `.gitignore` (lo armo abajo)
   - `package.json` (lo armo abajo)

Tocá **"Commit changes"**

## Paso 4: Deployar en Vercel (2 minutos)

1. Andá a https://vercel.com/new
2. Tocá **"Import Git Repository"**
3. Pegá la URL del repo de GitHub
4. Vercel va a detectar que es un proyecto React
5. Tocá **"Deploy"**
6. **Listo.** En 2-3 minutos te da una URL tipo:
   ```
   https://portfolio-dashboard.vercel.app
   ```

Esa es tu app. La abrís desde el celular, desktop, donde sea.

---

## Los archivos que necesitás

### 1. portfolio_dashboard.jsx
Ya está descargado en outputs. Es el código del dashboard.

### 2. package.json
Pegá esto en un archivo llamado `package.json` en la raíz:

```json
{
  "name": "portfolio-dashboard",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "next": "^14.0.0",
    "recharts": "^2.10.0",
    "lucide-react": "^0.263.0"
  }
}
```

### 3. next.config.js
Pegá esto en un archivo llamado `next.config.js`:

```js
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
}

module.exports = nextConfig
```

### 4. .gitignore
Pegá esto en un archivo llamado `.gitignore`:

```
node_modules
.next
dist
build
*.log
.env.local
.env
```

### 5. pages/index.js
Creá una carpeta `pages` y adentro un archivo `index.js` con esto:

```jsx
import PortfolioDashboard from '../portfolio_dashboard';

export default function Home() {
  return <PortfolioDashboard />;
}
```

---

## TL;DR (si solo querés copiar-pegar)

1. Crea repo en GitHub: https://github.com/new
2. Sube estos 4 archivos (opción drag & drop en GitHub):
   - `portfolio_dashboard.jsx`
   - `package.json`
   - `next.config.js`
   - `.gitignore`
   - Carpeta `pages/` con `index.js` adentro
3. Commit
4. Ve a https://vercel.com/new → Import repo
5. Deploy

En 5 minutos tenés tu URL. Listo.

---

## Si se te traba en algo

Mandale un mensaje acá en el chat y te ayudo. Es muy difícil que algo salga mal — Vercel es muy automático.
